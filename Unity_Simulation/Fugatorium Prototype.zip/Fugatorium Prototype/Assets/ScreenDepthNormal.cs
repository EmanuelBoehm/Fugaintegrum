﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

[ExecuteInEditMode]
[RequireComponent(typeof(Camera))]
public class ScreenDepthNormal : MonoBehaviour
{

    public Camera cam;
    public Material mat;
    [SerializeField]
    private Texture2D outputTex;

    private bool depth = true;

    private void Start()
    {
        if (cam == null)
        {
            cam = this.GetComponent<Camera>();
        }
        cam.depthTextureMode = DepthTextureMode.DepthNormals;

        if (mat == null)
        {
            // assign shader "Hidden/NewImageEffectShader" to Mat
            mat = new Material(Shader.Find("Hidden/NewImageEffectShader"));
        }
    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown("x"))
        {
            // Save PNG
            Debug.Log("Screenshot saved");
            System.IO.File.WriteAllBytes(Application.dataPath + "/ShaderOutput/" + "picture.jpg", outputTex.EncodeToPNG());

            // Save TXT
            float[,] twoDArray;
            twoDArray = getDepthValues(outputTex);
            writeArrayToData(twoDArray);

        }

        if (Input.GetKeyDown("y"))
        {
            if (depth)
            {
                depth = false;
            }else
            {
                depth = true;
            }
        }
    }

    public Texture2D GetOutputTex()
    {
        return outputTex;
    }

    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        // render source to screen
        //Graphics.Blit(source, destination);

        // render source to screen with shader
        if (depth)
        {
            Graphics.Blit(source, destination, mat);
            cam.farClipPlane = 15.4f;
        }
        else
        {
            Graphics.Blit(source, destination);
            cam.farClipPlane = 300f;
        }
        
        var width = cam.pixelWidth;
        var height = cam.pixelHeight;

        outputTex = new Texture2D(width, height, TextureFormat.ARGB32, false);
        outputTex.ReadPixels(new Rect(0, 0, width, height), 0, 0, false);
        
    }

    /**
     * take a Texture2D and converts it as a 2 dimentional floatarray
     * only works for grayscaled textures!
     * 
     * Lower means darker, means near to drone
     * highter means lighter, means further away from drone
     * 1 is the max value for distance -> Object to far away to detect
     * 
     * 
     */
    private float[,] getDepthValues(Texture2D texture)
    {
        float[,] output = new float[texture.height, texture.width];
        // For Testing, print the highest leftmost pixel as float value
        Debug.Log("Pixel in Corner: " + texture.GetPixel(0,0));
        
        for(int i = 0; i < texture.height; i++)
        {
            for (int j = 0; j < texture.width; j++)
            {
                // we take the red value but green and blue should be the same, since its a grayscale image
                output[i, j] = texture.GetPixel(i, j).r;
            }
        }
        return output;
    }

    /** 
     * takes a 2-dimentional Array and saves it as a .txt in Assets/picturetoArray.txt
     * Code taken from: https://stackoverflow.com/questions/32002789/how-to-write-value-of-multi-dimensional-array-to-a-text-file
     * slightly changed
     * 
     * Sollte von unten nach oben das Bild dann jeweils von links nach rechts printen
     * aktuell noch als bug, dass von der unteren Seite des Bildes etwas nach auf der anderen Seite geprintet wird
     */
    private void writeArrayToData (float [,] array)
    {
        FileStream fileStream = File.Open(@"D:\Unity\Fugatorium\Fugatorium Prototype\Assets\ShaderOutput\picturetoArray.txt", FileMode.Create);

        using (var sw = new StreamWriter(fileStream))
        {
            for (int i = 0; i < array.GetLength(1); i++)
            {
                for (int j = 0; j < array.GetLength(0); j++)
                {
                    sw.Write(array[j, i] + " ");
                }
                sw.Write("\n");
            }

            sw.Flush();
            sw.Close();
        }
    }
}
