﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
[RequireComponent(typeof(Camera))]
public class ScreenDepthNormal : MonoBehaviour
{

    public Camera cam;
    public Material mat;
    public Texture tex;
    private Texture2D outputTex;
    bool depth = true;

    private void Start()
    {
        if (cam == null)
        {
            cam = this.GetComponent<Camera>();
        }
        cam.depthTextureMode = DepthTextureMode.DepthNormals;

        if (mat == null)
        {
            // assign shader "Hidden/NewImageEffectShader" to Mat
            mat = new Material(Shader.Find("Hidden/NewImageEffectShader"));
        }
    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown("x"))
        {
            Debug.Log("Screenshot saved");
            System.IO.File.WriteAllBytes(Application.dataPath + "/" + "picture.png", outputTex.EncodeToPNG());
        }

        if (Input.GetKeyDown("y"))
        {
            if (depth)
            {
                depth = false;
            }else
            {
                depth = true;
            }
        }
    }

    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        // render source to screen
        //Graphics.Blit(source, destination);

        // render source to screen with shader
        if (depth)
        {
            Graphics.Blit(source, destination,mat);
            cam.farClipPlane = 15.4f;
        }
        else
        {
            Graphics.Blit(source, destination);
            cam.farClipPlane = 300f;
        }
        
        var width = cam.pixelWidth;
        var height = cam.pixelHeight;
        outputTex = new Texture2D(width, height, TextureFormat.ARGB32, false);
        outputTex.ReadPixels(new Rect(0, 0, width, height), 0, 0, false);
        
    }
}
