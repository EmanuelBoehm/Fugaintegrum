import UdpComms as U
import json 

class Drone:
    def __init__(self, udpIP="127.0.0.1",portTX=8000,portRX=8001):
        self.server = U.UdpComms(udpIP, portTX, portRX, enableRX=True, suppressWarnings=True)
 ##TODO func fly_forward()
    def fly_forward(self,dist=0):
        data = {
            "name":"fly_forward",
            "dist": dist,
        }
        self.server.SendData(str(data))
    def move_by(self, x=0.,y=0.,z=0.):
        data = {
                "name":"move_by",
                "x": x,
                "y": y,
                "z": z,
        }
        self.server.SendData(str(data))
    
    def move_by_relative(self, x=0.,y=0.,z=0.):
        #x,y,z = self.float_cs(x,y,z)
        print(x)
        data = {
            "name": "move_by_relative",
            "x": x,
            "y": y,
            "z": z,
        }
        self.server.SendData(str(data))

    def rotate_by(self, angle=0.):
        data = {
            "name" : "rotate_by",
            "angle": angle
        }
        self.server.SendData(str(data))
#-------server should be able to send:
#move_by_relative,
#move_by
#rotate_by

#-------server should be able to receive:
#current position
#current tilt
#current facing direction
#picture 
#-!! every package should be send with a timestemp

# Create UDP socket to use for sending (and receiving)
from pynput import keyboard


drone = Drone()

def on_press(key):
    if key == keyboard.Key.esc:
        return False  # stop listener
    try:
        k = key.char  # single-char keys
    except:
        k = key.name  # other keys
    if k == 'left':  # keys of interest
        # self.keys.append(k)  # store it in global-like variable
        drone.rotate_by(-2.)
    if k == 'right':  # keys of interest
        # self.keys.append(k)  # store it in global-like variable
        drone.rotate_by(2.)
    if k == 'up':  # keys of interest
        # self.keys.append(k)  # store it in global-like variable
        drone.fly_forward(2.)
    if k == 'down':  # keys of interest
        # self.keys.append(k)  # store it in global-like variable
        drone.fly_forward(2.)


listener = keyboard.Listener(on_press=on_press)
listener.start()  # start to listen on a separate thread
#listener.join()  # remove if main thread is polling self.keys


while True:
    data = drone.server.ReadReceivedData() # read data

    if data != None: # if NEW data has been received since last ReadReceivedData function call
        print(data) # print new received data


