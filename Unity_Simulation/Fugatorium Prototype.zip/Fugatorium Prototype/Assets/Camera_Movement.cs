﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera_Movement : MonoBehaviour
{
    private float moveSpeed = 0.3f;
    private float scrollSpeed = 10f;

    float horizontalInput;
    float verticalInput;
    float wheelInput;

    private Vector3 moveVector;

    // Start is called before the first frame update
    void Start()
    {
        moveVector = new Vector3(0, 0, 0);
    }

    // Update is called once per frame
    void Update()
    {
        moveVector.x = Input.GetAxisRaw("Horizontal");
        moveVector.z = Input.GetAxisRaw("Vertical");
        moveVector.y = Input.GetAxisRaw("Mouse ScrollWheel");
    }

    void FixedUpdate()
    {
        
        if (moveVector.x != 0 || moveVector.z != 0)
        {
            print(moveVector);
            transform.position += transform.forward * moveSpeed * moveVector.z;
            transform.position += transform.right * moveSpeed * moveVector.x;
        }
        



        if (moveVector.y != 0)
        {
            transform.position += scrollSpeed * new Vector3(0, moveVector.y, 0);
        }

        if (Input.GetKey("q"))
        {
            transform.eulerAngles = new Vector3(gameObject.transform.eulerAngles.x, gameObject.transform.eulerAngles.y - 5, gameObject.transform.eulerAngles.z);
        }
        if (Input.GetKey("e"))
        {
            transform.eulerAngles = new Vector3(gameObject.transform.eulerAngles.x, gameObject.transform.eulerAngles.y + 5, gameObject.transform.eulerAngles.z);
        }
    }
}
