import TcpServer as tcp
import UdpServer as udp
import json 
import struct
class Drone:
    def __init__(self, udpIP="127.0.0.1",portTX=8000,portRX=8001):
        self.tcp_server = tcp.TcpServer()
        self.udp_server = udp.UdpServer(udpIP,portTX,portRX,enableRX=True,suppressWarnings=True)
    def receive_data(self):
        """
        Returns the received positional data from unity
        :return:
        """
        return self.udp_server.ReadReceivedData()
    def receive_picture(self):
        """
        Returns the last received depth_frame from unity
        returned value cant be read again because it will be deleted from buffer after accessing this method
        :return:
        """
        return self.tcp_server.ReadReceivedData()
    def fly_forward(self,dist=0):
        data = {
            "name":"fly_forward",
            "dist": dist,
        }
        self.udp_server.SendData(str(data))
    def move_to(self, x=0.,y=0.,z=0.):
        data = {
                "name":"move_to",
                "x": x,
                "y": y,
                "z": z,
        }
        self.udp_server.SendData(str(data))
    
    def move_to_relative(self, x=0.,y=0.,z=0.):
        #x,y,z = self.float_cs(x,y,z)
        data = {
            "name": "move_to_relative",
            "x": x,
            "y": y,
            "z": z,
        }
        self.udp_server.SendData(str(data))

    def rotate_by(self, angle=0.):
        data = {
            "name" : "rotate_by",
            "angle": angle
        }
        self.udp_server.SendData(str(data))

def main():

    import pygame
    from PIL import Image
    import numpy as np
    from io import BytesIO

    drone = Drone()

    def key_control():
        for _ in pygame.event.get(): pass
        keyInput = pygame.key.get_pressed()
        pressed = lambda k: keyInput[getattr(pygame,'K_{}'.format(k))]
        if pressed('RIGHT'):
            drone.rotate_by(55.)
        if pressed('LEFT'):
            drone.rotate_by(-55.)
        if pressed('UP'):
            drone.fly_forward(3.)
        if pressed('DOWN'):
            drone.fly_forward(-3.)
        if pressed('c'):
            drone.move_to(0.,0.9,-10.)
        if pressed('w'):
            drone.move_to_relative(0.,1,0.)
        if pressed('s'):
            drone.move_to_relative(0.,-1,0.)
        if pressed('SPACE'):
            drone.move_to_relative(0.,0.,0.)


    pygame.init()
    gamefont = pygame.font.Font(None,32)
    screen = pygame.display.set_mode((960,600)) 
    textsurface = None
    picsurface = None
    while True:
        key_control()

        data = drone.receive_data() # read data
        pic = drone.receive_picture()

        if data != None: # if NEW data has been received since last ReadReceivedData function call
            textsurface = gamefont.render(data,False,(0,0,0))
        if pic != None:
            pic = Image.open(BytesIO(pic))
            #ar = np.array(pic)
            picsurface = pygame.image.fromstring(pic.tobytes(),pic.size,pic.mode)
        #get surface to screen
        if picsurface is not None:
            screen.blit(picsurface,[0,0])
        if textsurface is not None:
            screen.blit(textsurface,[0,0])

        pygame.display.update()

if __name__ == "__main__":
    main()
