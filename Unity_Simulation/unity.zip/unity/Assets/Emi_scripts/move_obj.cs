﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.Globalization;


public class move_obj : MonoBehaviour
{
	UdpSocket udp_server;
	TcpSocket tcp_server;
	[SerializeField] float speed = 10f;
	[SerializeField] float rotation_speed = 10f;
    ScreenDepthNormal screenDepthNormal;
	MoveQueue moveQ = new MoveQueue();
	Vector3 position;

	// this method will be called every time a string from python is received
	public void GetUpdate(string json_str) {
		string[] str = json_str.Split(',');
		string func_name = str[0].Split(':')[1];
		if (func_name.Contains("move_to")){ 
			Vector3 dest;
			if (func_name.Contains("move_to_rel")) {
				dest = parse_move_to_relative(str);
			} else {
				dest = parse_move_to(str);
			}
			this.moveQ.clear();
			this.moveQ.add(MoveEnum.Rotate, dest);
			this.moveQ.add(MoveEnum.Move, dest);
			this.moveQ.add_stand();

		} else if(func_name.Contains("rotate")) {
			float angle = parse_rotate(str);
			this.moveQ.clear();
			this.moveQ.add(MoveEnum.Rotate, angle);
		}
		else if(func_name.Contains("forward")) {
			float dist = parse_forward(str);
			this.moveQ.clear();
			this.moveQ.add(MoveEnum.Forward, dist);
		}
	}

	void Start() {
		this.position = transform.position;
		udp_server = FindObjectOfType<UdpSocket>();
		tcp_server = FindObjectOfType<TcpSocket>();
        screenDepthNormal = this.gameObject.GetComponent<ScreenDepthNormal>();
		InvokeRepeating("send_image", 0.1f, 0.2f);  //1s delay, repeat every 1s
		InvokeRepeating("send_data", 0f, 0.1f);
	}
	private void send_image(){
		tcp_server.send_image(screenDepthNormal.GetOutputTex().EncodeToPNG()); // hier muss Kamera Output rein
	}

	private void send_data() {
		string x = transform.position.x.ToString();
		string y = transform.position.y.ToString();
		string z = transform.position.z.ToString();
		string angle = transform.eulerAngles.y.ToString();
		udp_server.SendData("{\"pos\":[" + x +", "+ y + ", " + z +"], \"angle\":" + angle + "}");
	}

	private void Update() {
		this.position = transform.position;
		switch(this.moveQ.status()) {
			case MoveEnum.Stand:
				break;

			case MoveEnum.Rotate:
				if(this.moveQ.rotation_from_vector()) {
					this.moveQ.calc_angle_from_vec(transform.position, transform.forward);
				}
				if(-2f + 1f/rotation_speed < this.moveQ.get_rotation_angle() && this.moveQ.get_rotation_angle() < 2f - 1f/rotation_speed){
					this.moveQ.dequeue();
					break;
				}
				if(-this.rotation_speed < this.moveQ.get_rotation_angle() && this.moveQ.get_rotation_angle() < this.rotation_speed){
					float del =  this.moveQ.get_rotation_angle() / this.rotation_speed * 0.4f;
					this.moveQ.rotate_delta(del);
					transform.eulerAngles += new Vector3(0f,del, 0f);
				} else {
					float del = this.rotation_speed * Time.deltaTime * this.moveQ.get_rotation_direction();
					this.moveQ.rotate_delta(del);
					transform.eulerAngles += new Vector3(0f,del,0f);
				}
				break;

			case MoveEnum.Forward:
				//transform Queue head into moveType
				this.moveQ.move_forward_from(transform.position, transform.forward);
				if(Vector3.Distance(transform.position, this.moveQ.get_target()) < this.speed/ 20f && Vector3.Distance(transform.position, this.moveQ.get_target()) < 1f) {
					this.moveQ.dequeue();
					break;
				}
				transform.position = Vector3.MoveTowards(transform.position, this.moveQ.get_target(),this.speed * Time.deltaTime);
				break;

			case MoveEnum.Move:
				if(Vector3.Distance(transform.position, this.moveQ.get_target()) < this.speed/ 10f) {
					this.moveQ.dequeue();
					break;
				}
				transform.position = Vector3.MoveTowards(transform.position, this.moveQ.get_target(),this.speed * Time.deltaTime);
				break;
		}
	}

	private Vector3 parse_move_to_relative(string[] str) {
		float x = float.Parse(str[1].Split(':')[1],CultureInfo.InvariantCulture.NumberFormat);
		float y = float.Parse(str[2].Split(':')[1],CultureInfo.InvariantCulture.NumberFormat);
		string z_str = str[3].Split(':')[1];
		//removing "}"
		z_str = z_str.Substring(0, z_str.Length-1);
		
		float z = float.Parse(z_str,CultureInfo.InvariantCulture.NumberFormat);
		return(this.position + new Vector3(x,y,z));
	}
	private Vector3 parse_move_to(string[] str) {
		float x = float.Parse(str[1].Split(':')[1],CultureInfo.InvariantCulture.NumberFormat);
		float y = float.Parse(str[2].Split(':')[1],CultureInfo.InvariantCulture.NumberFormat);
		string z_str = str[3].Split(':')[1];
		//removing "}"
		z_str = z_str.Substring(0, z_str.Length-1);
		
		float z = float.Parse(z_str,CultureInfo.InvariantCulture.NumberFormat);
		return(new Vector3(x,y,z));
	}
	private float parse_rotate(string[] str) {
		string angle_str = str[1].Split(':')[1];
		//removing "}"
		angle_str = angle_str.Substring(0, angle_str.Length-1);
		
		float angle = float.Parse(angle_str,CultureInfo.InvariantCulture.NumberFormat);
		return(angle);
	}
	private float parse_forward(string[] str) {
		string dist_str = str[1].Split(':')[1];
		//removing "}"
		dist_str = dist_str.Substring(0, dist_str.Length-1);
		
		float dist = float.Parse(dist_str,CultureInfo.InvariantCulture.NumberFormat);
		return(dist);
	}

	public class MoveQueue {
		Movement current;
		Queue<Movement> queue;

		public MoveQueue() {
			this.current = new Movement(MoveEnum.Stand, 0f);
			this.queue = new Queue<Movement>();
		}
		public void pretty_print(){
			print("current: "+ current.ToString());
			print("\n queue: ");
			foreach (Movement m in queue) print(m.ToString() + " ");
		}
		public void add(MoveEnum e, float delta) {
			if(current.e == MoveEnum.Stand){
				this.current = new Movement(e,delta);
			} else {
			this.queue.Enqueue(new Movement(e, delta));
			}
		}
		public void add(MoveEnum e, Vector3 dest) {
			if(current.e == MoveEnum.Stand){
				this.current = new Movement(e,dest);
			} else {
				this.queue.Enqueue(new Movement(e,dest));
			}
		}
		public void add_stand() {
			this.queue.Enqueue(new Movement(MoveEnum.Stand, 0f));
		}

		public void clear() {
			this.queue.Clear();
			this.current = new Movement(MoveEnum.Stand, 0f);
		}

		public void dequeue() {
			if(this.queue.Count == 0) {
				this.current = new Movement(MoveEnum.Stand, 0f);
			}else {

				this.current = this.queue.Dequeue();
			}
		}

		public MoveEnum status(){
			return(this.current.e);
		}

		public bool rotation_from_vector() {
			return(this.current.delta == -1f);
		}
		public void calc_angle_from_vec(Vector3 pos, Vector3 forward) {
			Vector3 target_direction = this.current.target - pos;
			Vector2 a = new Vector2(target_direction.x, target_direction.z);
			Vector2 b = new Vector2(forward.x, forward.z);
			this.current.delta = Vector2.SignedAngle(a,b);
		} 

		public float get_rotation_angle(){
			if(this.current.e == MoveEnum.Rotate){
				return(this.current.delta);
			}
			return(0f);
		}
		public void rotate_delta(float del) {
			this.current.delta -= del;
		}

		public float get_rotation_direction(){
			if(this.current.e != MoveEnum.Rotate){
				return(1f);
			}
			if(this.get_rotation_angle() > 0) {
				return(1f);
			}
			return(-1f);
		}

		public void move_forward_from(Vector3 cur_pos,Vector3 forward_vec){
			this.current = new Movement(MoveEnum.Move, cur_pos + forward_vec * this.current.delta);
		}

		public Vector3 get_target() {
			return(this.current.target);
		}	
		
	}
	public class Movement {
		//Stand: get's nothing
		//Move: get's destination_vec
		//Rotate: get's angle or point to rotate to
		//Forward: get's forward distance
		public MoveEnum e;
		public float delta;
		public Vector3 target;

		public Movement(MoveEnum e, float delta) {
			this.e = e;
			this.delta = delta;
			this.target = new Vector3(0,0,0);
			switch(e) {
				case MoveEnum.Rotate:
					this.delta = delta;
					break;
				case MoveEnum.Forward:
					this.delta = delta;
					break;
				case MoveEnum.Stand:
					this.delta = 0f;
					break;
			}
		}
		public Movement(MoveEnum e, Vector3 target) {
			this.e = e;
			this.delta = -1f;
			switch(e) {
				case MoveEnum.Rotate:
					this.target = target;
					break;
				case MoveEnum.Move:
					this.target = target;
					break;
			}
		}
		
	}
	public enum MoveEnum {
		Stand,
		Move,
		Rotate,
		Forward,
	}
}