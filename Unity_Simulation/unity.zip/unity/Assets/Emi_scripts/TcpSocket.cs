using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Net.Sockets;
using System.Net;
using System;
using System.Threading;
using System.Text;
public class TcpSocket : MonoBehaviour
{

    // Start is called before the first frame update
    public String Host = "127.0.0.1";
    public Int32 Port = 9500;


    Thread receiveThread; // Receiving Thread
    TcpClient mySocket = null;
    NetworkStream stream = null;
    // Start is called before the first frame update
    move_obj move_obj;
    void Start()
    {   
        move_obj = FindObjectOfType<move_obj>();
        try {
            mySocket = new TcpClient(Host,Port);
        }
        catch(SocketException e) {
            print("Socket Error: " + e);
        }
    }
   
     private void SendMessage(byte[] data) {         
            if (mySocket == null && !mySocket.Connected) {             
                return;         
            }  		
            try { 			
                // Get a stream object for writing. 			
                //after stream get's cleaned the Connection will be closed from C#
                if(stream == null) {
                    this.stream = mySocket.GetStream(); 			
                }
                if (stream.CanWrite && data != null && data.Length != 0) {                 
                    // Write byte array to socketConnection stream.                 
                    stream.Write(data, 0, data.Length);                 
                    //print("Client sent his message - should be received by server");             
                }         
            } 		
            catch (SocketException socketException) {             
                print("Socket exception: " + socketException);         
            }     
        } 
    // Update is called once per frame
    void Update()
    {
        if(mySocket == null){
            print("socket not connected");

            try {
                mySocket = new TcpClient(Host,Port);
            }
            catch(SocketException e) {
                print("Socket Error: " + e);
            }
        }
    }

    public void send_image(byte[] img) {
        if(mySocket != null) {
            SendMessage(img);
        }
    }

    
    private void OnApplicationQuit()
    {
        if (mySocket != null && mySocket.Connected)
            this.stream = null;
            mySocket.Close();

    }
}
