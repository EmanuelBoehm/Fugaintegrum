﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera_Movement : MonoBehaviour
{
    private float moveSpeed = 0.3f;
    private float scrollSpeed = 10f;

    float horizontalInput;
    float verticalInput;
    float wheelInput;


    private GameObject Camera;
    private GameObject ExplosionPrefab;
    

    private Vector3 moveVector;

    // Start is called before the first frame update
    void Start()
    {
        Camera = Resources.Load("Prefabs/Camera") as GameObject;
        ExplosionPrefab = Resources.Load("Prefabs/Explotion") as GameObject;
       
    }
    

    public void moveForward()
    {
        print("klappt");
        moveVector.x = 1;
    }

    void FixedUpdate()
    {
        
        if (moveVector.x != 0 || moveVector.z != 0)
        {
            transform.position += transform.forward * moveSpeed * moveVector.z;
            transform.position += transform.right * moveSpeed * moveVector.x;
        }
      

        if (moveVector.y != 0)
        {
            transform.position += scrollSpeed * new Vector3(0, moveVector.y, 0);
        }

        if (Input.GetKey("q"))
        {
            transform.eulerAngles = new Vector3(gameObject.transform.eulerAngles.x, gameObject.transform.eulerAngles.y - 5, gameObject.transform.eulerAngles.z);
        }
        if (Input.GetKey("e"))
        {
            transform.eulerAngles = new Vector3(gameObject.transform.eulerAngles.x, gameObject.transform.eulerAngles.y + 5, gameObject.transform.eulerAngles.z);
        }
    }

     void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "noCollision")
        {
            
        }else
        {
            Explosion();
            Exception exception = new Exception("Collision");
            throw exception;
        }
    }

    void Explosion()
    {
        Vector3 deathpos = new Vector3(gameObject.transform.position.x, gameObject.transform.position.y, gameObject.transform.position.z);
        Instantiate(Camera,
            new Vector3(gameObject.transform.position.x, 8, gameObject.transform.position.z -3), 
            Quaternion.Euler(new Vector3(60,0,0)));
        
        Instantiate(ExplosionPrefab, deathpos, Quaternion.Euler(-90,0,0));
        this.gameObject.SetActive(false);
    }
}
