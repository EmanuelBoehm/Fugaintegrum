import TcpServer as tcp
import UdpComms as udp
import json 
import struct
class Drone:
    def __init__(self, udpIP="127.0.0.1",portTX=8000,portRX=8001):
        self.tcp_server = tcp.TcpServer()
        self.udp_server = udp.UdpComms(udpIP,portTX,portRX,enableRX=True,suppressWarnings=True)
    def receive_data(self):
        """
        Returns the received positional data from unity
        :return:
        """
        return self.udp_server.ReadReceivedData()
    def receive_picture(self):
        """
        Returns the last received depth_frame from unity
        returned value cant be read again because it will be deleted from buffer after accessing this method
        :return:
        """
        return self.tcp_server.ReadReceivedData()
    def fly_forward(self,dist=0):
        data = {
            "name":"fly_forward",
            "dist": dist,
        }
        self.udp_server.SendData(str(data))
    def move_by(self, x=0.,y=0.,z=0.):
        data = {
                "name":"move_by",
                "x": x,
                "y": y,
                "z": z,
        }
        self.udp_server.SendData(str(data))
    
    def move_by_relative(self, x=0.,y=0.,z=0.):
        #x,y,z = self.float_cs(x,y,z)
        print(x)
        data = {
            "name": "move_by_relative",
            "x": x,
            "y": y,
            "z": z,
        }
        self.udp_server.SendData(str(data))

    def rotate_by(self, angle=0.):
        data = {
            "name" : "rotate_by",
            "angle": angle
        }
        self.udp_server.SendData(str(data))

def main():
    drone = Drone()

    from pynput import keyboard
    def on_press(key):
        if key == keyboard.Key.esc:
            return False  # stop listener
        try:
            k = key.char  # single-char keys
        except:
            k = key.name  
        if k == 'left':  
            drone.rotate_by(-2.)
        if k == 'right':  
            drone.rotate_by(2.)
        if k == 'up':  
            drone.fly_forward(2.)
            print("jo")
        if k == 'down':  
            drone.fly_forward(2.)

    listener = keyboard.Listener(on_press=on_press)
    listener.start()  # start to listen on a separate thread
    #listener.join()  # remove if main thread is polling self.keys

    #### just for testing
    from PIL import Image
    import numpy as np
    from io import BytesIO
    i = 0
    while True:
        i = (i+1) % 5

        data = drone.receive_data() # read data
        pic = drone.receive_picture()
        if data != None: # if NEW data has been received since last ReadReceivedData function call
            print(data)
        if pic != None and i ==0:
            ar = np.array(Image.open(BytesIO(pic)))
            print(ar)


if __name__ == "__main__":
    main()