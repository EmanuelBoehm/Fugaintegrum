﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.Globalization;

enum Movement {
	Stand,
	Move,
	RotateTo,
	Rotate,
	Forward, // used for calculating end pos on forward going

}

public class move_obj : MonoBehaviour
{
	UdpSocket udp_server;
	TcpSocket tcp_server;
	Vector3 target_pos = new Vector3(0f,0f,0f);
	float forward_dist = 0f;
	float speed = 0.1f;
	float rotate_angle = 0f;
	Movement movement = Movement.Stand;
	//dist can't be neg. TODO find better way to get reset last_dist
	float last_dist = -1f;
    ScreenDepthNormal screenDepthNormal;
    Camera_Movement camScript;
// this method will be called every time a string from python is received
	public void GetUpdate(string json_str) {
		string[] str = json_str.Split(',');
		string func_name = str[0].Split(':')[1];
	
		//STRING containing x:f64,y:f64,z:f64.
		if(func_name.Contains("move_by_relative") ){ 
			//TODO: rotate drone to target position. move forward
			target_pos = parse_move_by_relative(str);
			this.movement = Movement.RotateTo;
			this.last_dist = -1f;

		} else if(func_name.Contains("move_by")) {
			//TODO: rotate drone to target position. move forward
			this.last_dist = -1f;
			target_pos = parse_move_by(str);
			this.movement = Movement.RotateTo;
		}
		if(func_name.Contains("rotate_by")) {
			this.rotate_angle = parse_rotate_by(str);
			this.movement = Movement.Rotate;
		}
		if(func_name.Contains("forward")) {

            //camScript.moveForward();
			this.forward_dist = parse_forward(str);
			this.movement = Movement.Forward;
		}

	}
	void Start() {
		udp_server = FindObjectOfType<UdpSocket>();
		tcp_server = FindObjectOfType<TcpSocket>();
        screenDepthNormal = this.gameObject.GetComponent<ScreenDepthNormal>();
        camScript = this.gameObject.GetComponent<Camera_Movement>();
		InvokeRepeating("send_image", 0.1f, 0.2f);  //1s delay, repeat every 1s
		InvokeRepeating("send_data", 0f, 0.1f);

	}
	private void send_image(){
		tcp_server.send_image(screenDepthNormal.outputTex.EncodeToPNG()); // hier muss Kamera Output rein
	}
	private void send_data() {
		string pos = transform.position.ToString();
		string angle = transform.eulerAngles.y.ToString();
		udp_server.SendData("pos:" + pos + ", angle: " + angle);
	}

	private float dist(Vector3 a, Vector3 b) {
		float x = a.x - b.x;
		float y = a.y - b.y;
		float z = a.z - b.z;
		return(x*x+y*y+z*z);
	}
	
	private void Update() {
		float d = dist(target_pos, transform.position);
		// -1 meaning the last dist wasn't set so far
		switch(this.movement) {
			case Movement.Move:
				if (last_dist == -1f) { // last_dist wasnt set
					this.last_dist = d;
				} else if ((d > last_dist && last_dist >= 0f) || d < 0.01f) {
					print("reached the target");
					this.last_dist = -1f;
					this.movement = Movement.Stand;
				} else {
					this.last_dist = d;
					transform.position += (target_pos - transform.position).normalized * speed;
				}
				break;
			case Movement.RotateTo:
				Vector3 direction = (this.target_pos - transform.position).normalized;
	
			//create the rotation we need to be in to look at the target
				Quaternion lookRotation = Quaternion.LookRotation(direction);
	
				//rotate us over time according to speed until we are in the required rotation
				transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, 20*this.speed);
				this.movement = Movement.Move;
				break;
			case Movement.Rotate:
				transform.eulerAngles = new Vector3(gameObject.transform.eulerAngles.x, gameObject.transform.eulerAngles.y + this.rotate_angle, gameObject.transform.eulerAngles.z);
				this.movement = Movement.Stand;
				break;
			
			case Movement.Forward:
				this.target_pos = (transform.position + transform.forward * this.forward_dist);
				this.movement = Movement.Move;
				break;
		}
	}

	private Vector3 parse_move_by_relative(string[] str) {
		float x = float.Parse(str[1].Split(':')[1],CultureInfo.InvariantCulture.NumberFormat);
		float y = float.Parse(str[2].Split(':')[1],CultureInfo.InvariantCulture.NumberFormat);
		string z_str = str[3].Split(':')[1];
		//removing "}"
		z_str = z_str.Substring(0, z_str.Length-1);
		
		float z = float.Parse(z_str,CultureInfo.InvariantCulture.NumberFormat);
		return(transform.position + new Vector3(x,y,z));
	}
	private Vector3 parse_move_by(string[] str) {
		float x = float.Parse(str[1].Split(':')[1],CultureInfo.InvariantCulture.NumberFormat);
		float y = float.Parse(str[2].Split(':')[1],CultureInfo.InvariantCulture.NumberFormat);
		string z_str = str[3].Split(':')[1];
		//removing "}"
		z_str = z_str.Substring(0, z_str.Length-1);
		
		float z = float.Parse(z_str,CultureInfo.InvariantCulture.NumberFormat);
		return(new Vector3(x,y,z));
	}
	private float parse_rotate_by(string[] str) {
		string angle_str = str[1].Split(':')[1];
		//removing "}"
		angle_str = angle_str.Substring(0, angle_str.Length-1);
		
		float angle = float.Parse(angle_str,CultureInfo.InvariantCulture.NumberFormat);
		return(angle);
	}
	private float parse_forward(string[] str) {
		string dist_str = str[1].Split(':')[1];
		//removing "}"
		dist_str = dist_str.Substring(0, dist_str.Length-1);
		
		float dist = float.Parse(dist_str,CultureInfo.InvariantCulture.NumberFormat);
		return(dist);
	}

}
