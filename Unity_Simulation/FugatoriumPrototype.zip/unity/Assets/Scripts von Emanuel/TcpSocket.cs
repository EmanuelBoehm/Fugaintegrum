using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Net.Sockets;
using System.Net;
using System;
using System.Threading;
using System.Text;
public class TcpSocket : MonoBehaviour
{

    // Start is called before the first frame update
    public String Host = "127.0.0.1";
    public Int32 Port = 9500;


    Thread receiveThread; // Receiving Thread
    TcpClient mySocket = null;
    NetworkStream stream = null;
    // Start is called before the first frame update
    move_obj move_obj;
    void Start()
    {   
        move_obj = FindObjectOfType<move_obj>();
        try {
            mySocket = new TcpClient(Host,Port);
        }
        catch(SocketException e) {
            print("Socket Error: " + e);
        }
    }
    void Awake() {

            receiveThread = new Thread(new ThreadStart(ReceiveData));
            receiveThread.IsBackground = true;
            receiveThread.Start();
    }
     private void SendMessage(byte[] data) {         
            if (mySocket == null && !mySocket.Connected) {             
                return;         
            }  		
            try { 			
                // Get a stream object for writing. 			
                //after stream get's cleaned the Connection will be closed from C#
                if(stream == null) {
                    this.stream = mySocket.GetStream(); 			
                }
                if (stream.CanWrite && data != null && data.Length != 0) {                 
                    // Write byte array to socketConnection stream.                 
                    stream.Write(data, 0, data.Length);                 
                    print("Client sent his message - should be received by server");             
                }         
            } 		
            catch (SocketException socketException) {             
                print("Socket exception: " + socketException);         
            }     
        } 
    // Update is called once per frame
    void Update()
    {
        if(mySocket == null){
            print("socket not connected");

            try {
                mySocket = new TcpClient(Host,Port);
            }
            catch(SocketException e) {
                print("Socket Error: " + e);
            }
        }
    }

    public void send_image(byte[] img) {
        if(mySocket != null) {
            SendMessage(img);
        }
    }

    private void ReceiveData()
    {   

        move_obj.GetUpdate("'name':'rotate_by','angle':3.");
        IPAddress ip = IPAddress.Parse(this.Host);
        TcpListener listener = new TcpListener(ip, this.Port);

        listener.Start();
        print("hello?");
        while (true)
        {
            print("l\n l\n l\n .dsa/dsadhjklghdfkg");
            try {
            Console.WriteLine("Server is listening on " + listener.LocalEndpoint);

            Console.WriteLine("Waiting for a connection...");

            Socket client = listener.AcceptSocket();

            Console.WriteLine("Connection accepted.");

            Console.WriteLine("Reading data...");

            byte[] data = new byte[5];
            int size = client.Receive(data);
            Console.WriteLine("Recieved data: ");
            for (int i = 0; i < size; i++)
                print(Convert.ToChar(data[i]));

            Console.WriteLine();

            client.Close();
            } catch (Exception err){
                print(err.ToString());
            }
        }

        //listener.Stop();
    }
    private void OnApplicationQuit()
    {
        if (mySocket != null && mySocket.Connected)
            this.stream = null;
            mySocket.Close();

    }
}
